"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Layers, FileText, ImageIcon, Gift } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-warm-white">
      <Header />

      {/* Hero Banner Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url(https://globaldesignsagency.com/assets/images/services/About.png)" }}
        />
        {/* Orange gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-flame-orange/80 to-flame-orange/60"></div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl lg:text-6xl font-bold text-warm-white mb-6">
              We're Passionate About <span className="text-warm-white">Design</span>
            </h1>
            <p className="text-lg lg:text-xl text-warm-white/90 leading-relaxed">
              With an unwavering passion for creativity and innovation, we go above and beyond to provide stellar design
              solutions. We are committed to each client's specific needs. From concept to execution, we put our heart
              and soul into every project, ensuring that our clients get nothing but the best.
            </p>
          </div>
        </div>
      </section>

      {/* Designing Beyond Boundaries Section */}
      <section className="py-20 bg-warm-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-ink-black">Designing Beyond Boundaries</h2>
              <p className="text-lg text-charcoal-gray leading-relaxed">
                At Global Design Agency, we believe in pushing creative boundaries. We are a passionate team of
                designers, developers, and marketers dedicated to bringing your vision to life. With a focus on
                innovation and excellence, we strive to exceed expectations and deliver tailored solutions that resonate
                with your audience. Whether you're a startup looking to establish your brand or an established business
                seeking a fresh perspective, we're here to help you navigate the ever-evolving digital landscape. Let's
                collaborate and create something extraordinary together!
              </p>
            </div>

            <div className="relative flex justify-center lg:justify-end">
              <img
                src="https://globaldesignsagency.com/assets/images/about-first.webp"
                alt="Professional designer working"
                className="w-full max-w-md h-auto object-cover rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Discover Your Design Potential Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative flex justify-center lg:justify-start order-2 lg:order-1">
              <img
                src="https://globaldesignsagency.com/assets/images/about-second.webp"
                alt="Creative designer at work"
                className="w-full max-w-md h-auto object-cover rounded-2xl shadow-lg"
              />
            </div>

            <div className="space-y-6 order-1 lg:order-2">
              <h2 className="text-3xl lg:text-4xl font-bold text-ink-black">Discover Your Design Potential</h2>
              <p className="text-lg text-charcoal-gray leading-relaxed">
                At Global Design Agency, our mission is to revolutionize digital experiences through inspired design
                solutions. We empower clients by fostering creativity, forging connections, and surpassing expectations,
                ensuring they stand out in a competitive landscape. Our collaborative approach combines strategic
                thinking, innovative design, and seamless execution, creating impactful brand experiences that drive
                inspiring creativity, and driving digital transformation. At Global Design Agency, we see a future where
                our exceptional design experiences empower businesses and individuals to thrive and leave a lasting
                impact.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Work Process Section - Reused from home page */}
      <section className="py-20 bg-charcoal-gray text-warm-white relative">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
          style={{ backgroundImage: "url(https://globaldesignsagency.com/assets/images/work-background.webp)" }}
        />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Our Work Approach</h2>
            <p className="text-lg text-warm-white/80 max-w-3xl mx-auto">
              Experience Our Design Journey: Our work approach emphasizes top-notch work, teamwork, and attention to
              detail, ensuring each project exceeds expectations.
            </p>
          </div>

          <div className="relative">
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-flame-orange transform -translate-y-1/2"></div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
              <div className="text-center space-y-4">
                <div className="bg-flame-orange rounded-full w-32 h-32 flex items-center justify-center mx-auto relative">
                  <Layers size={48} className="text-warm-white" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-warm-white rounded-full flex items-center justify-center text-xs font-bold text-flame-orange">
                    1
                  </div>
                </div>
                <h3 className="text-xl font-semibold">Design Brief</h3>
                <p className="text-sm text-warm-white/80 leading-relaxed">
                  Our design brief outlines your vision and project goals, ensuring a clear direction for our
                  collaboration.
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="bg-flame-orange rounded-full w-32 h-32 flex items-center justify-center mx-auto relative">
                  <FileText size={48} className="text-warm-white" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-warm-white rounded-full flex items-center justify-center text-xs font-bold text-flame-orange">
                    2
                  </div>
                </div>
                <h3 className="text-xl font-semibold">Sketch</h3>
                <p className="text-sm text-warm-white/80 leading-relaxed">
                  In this step, we translate your vision into initial design sketches for further directions.
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="bg-flame-orange rounded-full w-32 h-32 flex items-center justify-center mx-auto relative">
                  <ImageIcon size={48} className="text-warm-white" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-warm-white rounded-full flex items-center justify-center text-xs font-bold text-flame-orange">
                    3
                  </div>
                </div>
                <h3 className="text-xl font-semibold">Revision</h3>
                <p className="text-sm text-warm-white/80 leading-relaxed">
                  In this step, we translate your vision into initial design sketches for further directions.
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="bg-flame-orange rounded-full w-32 h-32 flex items-center justify-center mx-auto relative">
                  <Gift size={48} className="text-warm-white" />
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-warm-white rounded-full flex items-center justify-center text-xs font-bold text-flame-orange">
                    4
                  </div>
                </div>
                <h3 className="text-xl font-semibold">Final Delivery</h3>
                <p className="text-sm text-warm-white/80 leading-relaxed">
                  After approval, we ensure delivery of polished designs, ready for implementation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Meet Our Dynamic Design Crew Section */}
      <section className="py-20 bg-warm-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-ink-black">Meet Our Dynamic Design Crew</h2>
              <p className="text-lg text-charcoal-gray leading-relaxed">
                Step into the world of Global Design Agency, where creativity flourishes and innovation thrives. Meet
                the family behind the brand – a close-knit team of passionate creatives and tech enthusiasts united by
                our mission to redefine digital experiences. From seasoned designers to brilliant developers and savvy
                marketers, we bring diverse perspectives to every project, ensuring a fresh and dynamic approach.
                Together, we collaborate seamlessly to bring your vision to life, crafting designs that not only
                captivate and inspire. Get to know the brilliant minds driving our design magic and join us on a journey
                of creativity, innovation, and boundless possibilities.
              </p>
            </div>

            <div className="relative flex justify-center lg:justify-end">
              <img
                src="https://globaldesignsagency.com/assets/images/about-third.webp"
                alt="Professional team member"
                className="w-full max-w-md h-auto object-cover rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
